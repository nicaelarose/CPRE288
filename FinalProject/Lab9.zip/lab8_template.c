/**
 * @file lab8_template.c
 * @author
 * Template file for CprE 288 Lab 8
 */

#include "Timer.h"
#include "lcd.h"
#include "servo.h"
#include "resetSimulation.h"

// Uncomment or add any include directives that are needed

#define REPLACEME 0

int main(void) {
    resetSimulationBoard();
	timer_init(); // Must be called before lcd_init(), which uses timer functions
	lcd_init();
	servo_init();

	timer_waitMillis(1000);
	servo_move(-60);
	timer_waitMillis(1000);
	servo_move(120);
	timer_waitMillis(1000);
	servo_move(-30);
	//servo_move(30);
	//servo_move(150);
	//servo_move(90);

	// YOUR CODE HERE

	while(1)
	{

      // YOUR CODE HERE
	    timer_waitMillis(300);


	}

}
