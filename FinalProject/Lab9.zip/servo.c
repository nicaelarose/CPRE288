/**
 * Driver for ping sensor
 * @file ping.c
 * @author
 */

#include "Timer.h"
#include "driverlib/interrupt.h"
#include "lcd.h"
#include "math.h"
#include "stdio.h"



void servo_init(void)
{

    // YOUR CODE HERE
    SYSCTL_RCGCGPIO_R |= 0b10;
    SYSCTL_RCGCTIMER_R |= 0b10;

    GPIO_PORTB_AFSEL_R |= 0b100000; //reconfig
    GPIO_PORTB_PCTL_R |= 0x700000; //reconfig

    GPIO_PORTB_DEN_R |= 0b100000;
    GPIO_PORTB_DIR_R |= 0b100000;

    TIMER1_CTL_R &= ~0x100;
    TIMER1_CFG_R = 0x4;
    TIMER1_TBMR_R = 0x80A;
    //TIMER1_TBMR_R = 0xA;
    TIMER1_CTL_R &= ~0x4000; //dont invert
    TIMER1_TBPR_R = 0x04;
    TIMER1_TBILR_R = 0xE200; //convert 20millis to clock cycles
    TIMER1_TBPMR_R = 0x0;
    TIMER1_TBMATCHR_R = 0x0;
    //320,000 clock cycles per 20 millis = 4E200
    //TIMER1_TBPMR_R = 0x0;
    //TIMER1_TBMATCHR_R = 0x0; //only holds 16bits, set pmr to compensate


    TIMER1_CTL_R |= 0x100;
}

int servo_move(float degrees)  //only modify Match values
{//degrees->millis->clock cycle->match
    //Degree Match=320,000-(best fit equation)*(convert from degrees to clock cycle)
    //uncalibrated 90 degs = 296,000
    //18.5 ms = 0x48440
    int conversion = 320000-(((degrees/180)+1)*pow(10,-3))*(1/(6.25*pow(10,-8)));

    TIMER1_TBPMR_R = conversion>>16;
    TIMER1_TBMATCHR_R = conversion;


    //GPIO_PORTB_DATA_R |= 0b10000;
    //while ((TIMER1_TBPR_R << 8 + TIMER1_TBILR_R) != (TIMER1_TBPMR_R << 8 + TIMER1_TBMATCHR_R)){}
    //GPIO_PORTB_DATA_R &= ~0b10000;
    //TIMER1_CTL_R |= 0x100;
}







