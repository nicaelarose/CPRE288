/*
 * movement.c
 *
 *  Created on: Feb 11, 2021
 *      Author: cgpinta
 */
#include "open_interface.h"
#include "movement.h"
#include "cyBot_uart.h"  // Functions for communicating between CyBot and Putty (via UART)
#include "cyBot_FindObjects.h"
#include "lab4_template.h"

double move_forward(oi_t *sensor_data, double distance_mm){
    // the following code could be put in function move_forward()
    double sum = 0; // distance member in oi_t struct is type double
    oi_setWheels(100,100); //move forward at full speed
    while (sum <= distance_mm-0) {
        oi_update(sensor_data);
        if(sensor_data->bumpLeft) {
               lcd_puts("Left");
               move_backward(sensor_data,150);
               turn_right(sensor_data, 90);
               move_forward(sensor_data,250);
               turn_left(sensor_data, 90);
               findingObjects(sensor_data);
               //oi_setWheels(100,100); //move forward at full speed
           }
           else if(sensor_data->bumpRight) {
               lcd_puts("Right");
               move_backward(sensor_data,150);
               turn_left(sensor_data, 90);
               move_forward(sensor_data,250);
               turn_right(sensor_data, 90);
               findingObjects(sensor_data);
               //oi_setWheels(100,100); //move forward at full speed
           }
        sum += sensor_data -> distance; // use -> notation since pointer
        //printf("%f mm\n", sum);
    }
    oi_setWheels(0,0); //stop
    return sum;
}
double move_backward(oi_t *sensor_data, double distance_mm){
    // the following code could be put in function move_forward()
    double sum = 0; // distance member in oi_t struct is type double
    oi_setWheels(-100,-100); //move forward at full speed
    while (sum >= -150) {
        oi_update(sensor_data);
        sum += sensor_data -> distance ; // use -> notation since pointer
         printf("%f mm\n", sum);
    }
    oi_setWheels(0,0); //stop
    return sum;
}
double turn_right(oi_t *sensor_data,double degrees){
    double sum = 0; // distance member in oi_t struct is type double
    oi_setWheels(40,-40); //move forward at full speed
    while (sum <= degrees) {
        lcd_init();
        oi_update(sensor_data);
        sum += sensor_data -> angle; // use -> notation since pointer
        //printf("%f degrees\n", sum);
    }
    oi_setWheels(0,0); //stop
    return sum;
}
double turn_left(oi_t *sensor_data,double degrees){
    double sum = 0; // distance member in oi_t struct is type double
    oi_setWheels(-40,40); //move forward at full speed
    while (sum >= -1*degrees) {
        lcd_init();
        oi_update(sensor_data);
        sum += sensor_data -> angle; // use -> notation since pointer
        //double d =  oi_getDegrees(sensor_data);
        //printf("%f degrees\n", sum);

    }
        oi_setWheels(0,0); //stop
        return sum;
}


