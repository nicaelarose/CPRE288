#ifndef LAB4_TEMPLATE_H_
#define LAB4_TEMPLATE_H_


void findingObjects(oi_t *sensor_data);

#endif
