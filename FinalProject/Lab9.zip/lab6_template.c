/**
 * lab5_template.c
 *
 * Template file for CprE 288 Lab 5
 *
 * @author Zhao Zhang, Chad Nelson, Zachary Glanz
 * @date 08/14/2016
 *
 * @author Phillip Jones, updated 6/4/2019
 * @author Diane Rover, updated 2/25/2021
 */

#include "Timer.h"
#include "lcd.h"
#include "cyBot_Scan.h"  // For scan sensors
#include "uart.h"

// Uncomment or add any include directives that are needed
// #include "open_interface.h"
// #include "movement.h"
// #include "button.h"


#warning "Possible unimplemented functions"
#define REPLACEME 0


int main_6old(void) {
 //   resetSimulationBoard();
    timer_init(); // Must be called before lcd_init(), which uses timer functions
    lcd_init();
    uart_init();
   cyBOT_init_Scan();

    // YOUR CODE HERE

   cyBOT_Scan_t getScan;
/*
   while(true)
   {
       if(uart_receive()=='\r'){
           uart_sendChar('\n');
       }
       else{
       uart_sendChar(uart_receive());
       }
   }
}
*/
     while(true)
            {

                if(uart_receive()=='g'){
                    int i = 0;
                    while(i<180)
                    {
                    cyBOT_Scan(i, &getScan);
                    uart_sendStr(i);
                    //uart_sendChar('l');//uart_receive());
                    i += 5;
                    }
                        }
                        else{
       uart_sendChar(uart_receive());
       }
                }

            }



